import argparse
import gzip
import shutil
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app.paths import get_default_data_root, get_project_root
from app.ui import launch_app

APP_NAME = "hOCG_H"


def _resolve_db_path(db_arg: str | None) -> str:
    if db_arg:
        return str(Path(db_arg).expanduser())
    data_root = get_default_data_root(APP_NAME)
    return str(data_root / "hololive_ocg.sqlite")


def _copy_bundled_db(db_path: Path) -> None:
    if db_path.exists() and db_path.stat().st_size > 0:
        return

    project_root = get_project_root()
    bundled_candidates = [
        project_root / "app" / "hololive_ocg.sqlite",
        project_root / "app" / "assets" / "hololive_ocg.sqlite",
        project_root / "app" / "assets" / "hololive_ocg.sqlite.gz",
        project_root / "data" / "hololive_ocg.sqlite",
        project_root / "assets" / "hololive_ocg.sqlite",
    ]

    for candidate in bundled_candidates:
        if not candidate.exists() or not candidate.is_file():
            continue
        if candidate.resolve() == db_path.resolve():
            return
        db_path.parent.mkdir(parents=True, exist_ok=True)
        if candidate.suffix == ".gz":
            with gzip.open(candidate, "rb") as f_in, open(db_path, "wb") as f_out:
                shutil.copyfileobj(f_in, f_out)
        else:
            shutil.copyfile(candidate, db_path)
        return


def main() -> None:
    ap = argparse.ArgumentParser(description="Launch hOCG_H UI.")
    ap.add_argument("--db", default=None)
    args = ap.parse_args()
    db_path = _resolve_db_path(args.db)
    if args.db is None:
        _copy_bundled_db(Path(db_path))
    launch_app(db_path)

if __name__ == "__main__":
    main()
