from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path


def get_project_root() -> Path:
    # app/paths.py -> app/ -> project root
    return Path(__file__).resolve().parents[1]


def _is_writable_dir(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".write_test"
        with open(probe, "w", encoding="utf-8") as f:
            f.write("ok")
        probe.unlink()
        return True
    except Exception:
        return False


def get_app_data_dir(app_name: str) -> Path:
    candidates: list[Path] = []

    if sys.platform == "ios":
        home = Path.home()
        candidates = [
            home / "Documents",
            home / "Library" / "Application Support",
            home / "Library",
            home,
        ]
    elif sys.platform == "darwin":
        candidates = [Path.home() / "Library" / "Application Support"]
    elif sys.platform.startswith("win"):
        candidates = [Path(os.getenv("APPDATA") or Path.home() / "AppData" / "Roaming")]
    else:
        candidates = [Path(os.getenv("XDG_DATA_HOME") or Path.home() / ".local" / "share")]

    for base in candidates:
        path = base / app_name
        if _is_writable_dir(path):
            return path

    fallback = Path(tempfile.gettempdir()) / app_name
    fallback.mkdir(parents=True, exist_ok=True)
    return fallback


def get_default_data_root(app_name: str) -> Path:
    project_root = get_project_root()
    preferred = project_root / "data"
    if _is_writable_dir(preferred):
        return preferred
    return get_app_data_dir(app_name)
